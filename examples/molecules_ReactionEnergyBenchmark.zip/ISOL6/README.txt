ISOL6 dataset of reaction energies. Reactants are called e_X.xyz and products p_X.xyz.
XYZ files from https://doi.org/10.1039/C003951A 
Reactions 3, 9, 10, 13, 14, and 20 are the ISOL6, but no. 20 contains F atoms so excluded here
