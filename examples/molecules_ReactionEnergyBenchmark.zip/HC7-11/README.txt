HC7/11 dataset
XYZ files from https://doi.org/10.1021/jz200616w
